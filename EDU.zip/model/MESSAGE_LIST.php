<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$_STUDENT_CREATION = "Welcome to EDU Your user id : is";
$_EVENT_CREATION_SMS = "New Event creaated ";

?>