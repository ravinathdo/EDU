<li class="<?php if($_SESSION['menu']=='home') echo 'active';?>"><a href="home.php">Home</a></li>
<li class="<?php if($_SESSION['menu']=='my_subject') echo 'active';?>"><a href="lecture_subjects.php">My Subject</a></li>
<li class="<?php if($_SESSION['menu']=='assignment_exam') echo 'active';?>"><a href="lecture_marking.php">Assignment / Exam</a></li>
<li class="<?php if($_SESSION['menu']=='profile') echo 'active';?>"><a href="lecture_profile.php">Profile</a></li>
<li class="<?php if($_SESSION['menu']=='report') echo 'active';?>"><a href="lecture_reports.php">Reports</a></li>
